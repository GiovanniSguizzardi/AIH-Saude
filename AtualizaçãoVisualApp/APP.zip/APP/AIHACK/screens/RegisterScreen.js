import React, { useState } from 'react';
import { View, Text, TextInput, Pressable, StyleSheet } from 'react-native';

function RegisterScreen({ navigation }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  return (
    <View style={styles.container}>
      <img src={"login-register.png"} alt='imagem' style={{height:180, width:180}}/>
      <Text style={styles.title}>Registro AIH Saúde</Text>
      <Text style={styles.subtitle}>Registre-se para continuar...</Text>

      <Text style={styles.campoTitle}>Campo E-Mail:</Text>
      <TextInput
        style={styles.input}
        autoFocus={true}
        placeholder="Digite o e-mail..."
        value={email}
        onChangeText={setEmail}/>

      <Text style={styles.campoTitle}>Campo Senha:</Text>
      <TextInput
        style={styles.input}
        placeholder="Digite a senha..."
        secureTextEntry
        maxLength={12}
        value={password}
        onChangeText={setPassword}/>

      <Pressable style={styles.button} onPress={() => navigation.navigate('Login')}>
        <Text style={styles.buttonText}>Enviar registro ao sistema</Text>
      </Pressable>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#FAEBD7'
  },
  title: {
    fontSize: 30,
    fontWeight: 'bold',
    marginBottom: 5
  },
  subtitle: {
    fontSize: 15,
    marginBottom: 20
  },
  campoTitle: {
    marginTop:5,
    marginRight:130,
    fontSize: 15,
    fontWeight: 'bold',
  },
  input: {
    width: '80%',
    padding: 10,
    marginVertical: 10,
    borderWidth: 1,
    borderColor: '#000000',
    borderRadius: 5,
  },
  button:{
    marginTop:10,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 10,
    paddingHorizontal: 30,
    borderRadius: 4,
    backgroundColor: 'black',
  },
  button2:{
    marginTop:150,
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 20,
    paddingHorizontal: 40,
    borderRadius: 20,
    backgroundColor: '#2F4F4F',
  },
  buttonText:{
    fontSize: 15,
    fontWeight: 'bold',
    color: 'white',
  },
  buttonText2:{
    fontSize: 15,
    fontWeight: 'bold',
    color: 'white',
  }
});

export default RegisterScreen;